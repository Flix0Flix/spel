import Phaser from "phaser";

export default class Player extends Phaser.GameObjects.Rectangle {
  /**
   * @param {Phaser.Scene} scene 
   */
  constructor(scene, x, y, onDiedCallback) {
    super(scene, x, y, 40, 40, 0x2277ff)

    this.speed = 400
    this.jumpStrength = 400
    this.jumpKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.UP)
    this.onDiedCallback = onDiedCallback

    scene.add.existing(this)
    scene.physics.add.existing(this)
  }

  update() {

    this.body.setVelocityX(this.speed)
    
    if(this.jumpKey.isDown && this.body.touching.down) {
      this.body.setVelocityY(-this.jumpStrength)
    }

    if(this.y > this.scene.game.config.height || this.body.touching.right) {
      this.onDiedCallback()
    }
  }

}